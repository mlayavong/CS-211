#ifndef CLASSNODE_h
#define CLASSNODE_h

#include <string> 
using namespace std; 


class Node
{ 
 private: 
  string name; 
  string phoneNumber; 
  Node* next; 
  friend class LL; 

};
#endif 
