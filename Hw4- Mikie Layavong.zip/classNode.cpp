#include "classNode.h" 
#include <iostream> 


Node::Node() 
{ 
  name = ""; 
  phoneNumber = ""; 
  next = nullptr; 
}

void Node::setNode(string n, string phone) 
{ 

  name = n; 
  phoneNumber = phone ; 


}
