#ifndef LL_h
#define LL_h

#include <string> 
#include "classNode.h"
using namespace std; 


class LL 
{
   
 private: 
  Node* head; 
  void destroy();
 public: 
  //constructors and destructors 
  LL();  
  ~LL(); 
  LL(const LL& source); 
  LL& operator = (const LL& source); 
  
  //members of the class 
  void append(string pName, string phone); 
  void print() const; 
  void insertAtBegin(string pName, string phone); 
  void searchByName(string pName); 
  void readFromArrays(string nArr[], string pArr[], int size);
  void insert(string pName, string phone); 
  void insertAtPos(string pName, string phone, int pos) ; 
  void printReverse(); 
  void updateNumber(string pName, string newPhone); 
  void removeRecord(string pName); 
  void reverse(); 
};
#endif
