#include "LL.h" 
#include <iostream> 


//contructor of the linked list 
LL::LL() 
{ 
  head = nullptr; 
}

//this function prints the list in reverse 
void LL:: printReverse()
{
  reverse(); 
  print();
}
//searches for name of the persons number to update then if found updates the number 
void LL:: updateNumber(string pName, string phone)  
{ 
  Node* nodePtr; 
  nodePtr = head; 
  
  while(nodePtr != nullptr && nodePtr -> name != pName) 
    { 
      nodePtr= nodePtr -> next; 
    }
      if(nodePtr == nullptr) 
	cout << pName << " does not exist." << endl; 
      else 
	nodePtr -> phoneNumber = phone;

}

//this function removes the record if the name is in the list 
void LL:: removeRecord(string pName)
{ 
  Node* nodePtr;
  Node* previous; 

  if(head->name == pName) 
    { 
      nodePtr = head -> next; 
      delete head; 
      head = nodePtr; 

    }
  else
    { 
      nodePtr = head; 
      while(nodePtr != nullptr && nodePtr -> name != pName) 
	{ 
	  previous = nodePtr; 
	  nodePtr = nodePtr -> next; 
	}
      if(nodePtr) 
	{ 
	  previous -> next = nodePtr -> next; 
	  delete nodePtr; 
	}
      else
	cout << pName << " does not exist" << endl; 
    }

}
//reverse the list order
void LL:: reverse() 
{ 
  Node* nodePtr; 
  Node* previous; 
  Node* nextPtr; 
  nodePtr = head; 
  previous = nullptr;

  while(nodePtr!= nullptr) 
    {
      nextPtr = nodePtr-> next; 
      nodePtr -> next = previous; 
      previous = nodePtr; 
      nodePtr = nextPtr;
    }
   head = previous; 

} 
//this function inserts a new person at a certain position in the link list 
void LL:: insertAtPos(string pName, string phone, int pos)
{ 
 
  Node* previous; 
  Node *nodePtr; 
  Node* newNode; 
  int count = 1; 

  newNode = new Node; 
  newNode -> name = pName; 
  newNode -> phoneNumber = phone; 
  newNode->next = nullptr; 

  nodePtr = head;

  if(head != nullptr)
    { 

      while(nodePtr -> next != nullptr && count != pos)  
	{
	  previous = nodePtr; 
	  nodePtr = nodePtr -> next; 
	  count++; 
	}
      if(pos == 1) 
	insertAtBegin(pName, phone);
      else if(nodePtr -> next == nullptr && pos == count + 1)
	append(pName, phone); 
      else if(pos > count + 1)
	append(pName, phone); 
      else 
	{
	  previous -> next = newNode; 
	  newNode -> next = nodePtr; 
	}
    }
	      

}
//inserts the new name and number at the end of the list
void LL :: insert(string pName, string phone) 
{ 
  Node* nodePtr; 
  Node* newNode = new Node; 

  newNode -> name = pName; 
  newNode -> phoneNumber = phone; 
  newNode -> next = nullptr; 

  if(head == nullptr || head -> name >= newNode -> name) 
    {   
      newNode -> next = head;
      head = newNode;  
    } 
 else 
    {
      if(!head) 
	head = newNode; 
      else
	nodePtr = head; 
      while(nodePtr -> next != nullptr && nodePtr -> next -> name < newNode -> name) 
	{ 
	  nodePtr = nodePtr -> next; 
	}
      newNode -> next = nodePtr -> next;
      nodePtr -> next = newNode; 

    }


}
//this function reads data from two arrays and sorts them into a linked list 
void LL:: readFromArrays(string nArr[], string pArr[], int size) 
{ 
  Node* nodePtr; 
  Node* newNode; 
 

  for(int i = 0; i < size; i++) 
     { 
       newNode = new Node; 
       newNode -> name = nArr[i]; 

       newNode -> phoneNumber = pArr[i]; 
       newNode -> next = nullptr; 

       if(!head)
	 head = newNode; 
       else
	 {
	   nodePtr = head; 
	   while(nodePtr -> next )
	     {
	       nodePtr = nodePtr ->next;
	     }
	   nodePtr -> next = newNode; 
	   
	 }
     }
} 
//this function adds a new persons name and number into the linked list
void LL:: append(string pName, string phone) 
{

  Node *newNode; 
  Node *nodePtr; 
 
  newNode = new Node;
  newNode -> name = pName; 
  newNode -> phoneNumber = phone;
  newNode -> next = nullptr; 

  if(!head) 
    head = newNode; 
  else 
    { 
      nodePtr = head; 

      while(nodePtr -> next) 
	
	nodePtr = nodePtr -> next; 
      
      nodePtr -> next = newNode; 
	
    } 
}

//prints out the linked list
void LL:: print() const
{
  Node* nodePtr; 
  int count = 0; 
  nodePtr = head; 

  while(nodePtr)
    {
      count++; 
      cout << count << ". " <<nodePtr -> name << ", " << nodePtr -> phoneNumber << endl; 

      nodePtr = nodePtr -> next; 


    }

}
//inserts new persons data into the linked list but at the beginning only
void LL:: insertAtBegin(string pName, string phone) 
{
  Node* newNode; // a new node 
  Node* nodePtr; //traverse the list
  Node* previousNode; // the previous node 

  //allocate a new node and store the contents 
  newNode = new Node; 
  newNode -> name = pName; 
  newNode -> phoneNumber = phone; 

  //if there are no nodes in the list make newNode the first node 
  if(!head) 
    {
      head = newNode; 
      newNode -> next= nullptr; 
    }
  else //otherwise, insert newNode 
    { 
      //position nodePtr at the head of the list 
      nodePtr = head; 
      //initialize previousNode to nullptr
      previousNode = nullptr; 

      //skips all nodes whose value is less than the contents
      while(nodePtr != nullptr && nodePtr -> name < pName && nodePtr -> phoneNumber < phone)
	{ 
	  previousNode = nodePtr; 
	  nodePtr = nodePtr -> next; 
	}

      //if the new node is to be the 1st in the list insert it before all other nodes 
      if(previousNode == nullptr)
	{ 
	  head = newNode; 
	  newNode -> next = nodePtr; 
	}
      else //otherwise insert after the previous node
	{ 
	  previousNode -> next = newNode; 
	  newNode -> next = nodePtr; 

	}
    }
}
//searches the link list for a person if they are there or not 
void LL:: searchByName(string pName)
{ 
  Node* nodePtr; 
  bool flag = false; 
  nodePtr = head; 
   while(nodePtr) 
     { 
      if(pName == nodePtr -> name) 
	{
	  cout << "Here is " << pName <<  "'s "<< " phone number: " <<nodePtr -> phoneNumber << endl; 
	  flag = true;  
	}
      nodePtr = nodePtr -> next; 
       
     }
   if(flag!= true) 
     cout << pName << " does not exist" << endl; 

}
//destroys the linked list
void LL:: destroy()
{
  Node* nodePtr; 
  Node* nextNode; 

  nodePtr = head; 

  while(nodePtr != nullptr) 
    { 
      nextNode = nodePtr -> next; 

      delete nodePtr; 

      nodePtr = nextNode; 
    }
 


}
//destructor 
LL::~LL() 
{ 
  destroy(); 

}
//copy constructor to do a deep copy
LL::LL(const LL& source) 
{ 
  Node* nodePtr; 

  nodePtr = source.head; 

  while(nodePtr != nullptr) 
    { 
      append(nodePtr -> name, nodePtr -> phoneNumber); 
      nodePtr = nodePtr -> next;  

    }

}
//copies the linked list into another linked list 
LL& LL:: operator = (const LL& source) 
{
  Node* nodePtr; 
  nodePtr = source.head; 
  while(nodePtr != nullptr) 
    { 
      append(nodePtr -> name, nodePtr -> phoneNumber); 
      nodePtr = nodePtr -> next; 

    }


}
/*
bool LL:: operator == (const LL& L1)
{ 
  Node* nodePtr; 
  Node* copyPtr; 

  nodePtr = head; 
  copyPtr = L1.head; 

  while(nodePtr != nullptr && copyPtr != nullptr) 
    {
      if(nodePtr == nullptr && copyPtr == nullptr) 
	return true;
      else if(nodePtr == nullptr && copyPtr != nullptr)
	return false; 
      else if(nodePtr != nullptr && copyPtr == nullptr) 
	return false;  
      else if(nodePtr -> name == copyPtr -> name && nodePtr -> phoneNumber == copyPtr -> phoneNumber) 
	return true;   
      nodePtr = nodePtr -> next; 
      copyPtr = copyPtr -> next; 

    }


}
*/
