/*
In this assignment, you are going to design a directory of restaurants that helps restaurant owners advertise their business and users find great local restaurants. Each restaurant creates a profile with basic listing information such as restaurant name, location, contact information, type of food it serves, rating, and number of reviewers. Users can look up this directory to find places of interest and can submit a review to a restaurant service using a one to five-star rating system. The program allows several functionalities such as: adding anew restaurant listing to the directory, deleting a listing if the restaurant closed, displaying restaurants details, finding specific restaurant(s), and rating a restaurant. In this assignment, you are going to design a directory of restaurants that helps restaurant owners advertise their business and users find great local restaurants. Each restaurant creates a profile with basic
listing information such as restaurant name, location, contact information, type of food it serves, rating,
and number of reviewers. Users can look up this directory to find places of interest and can submit a
review to a restaurant service using a one to five-star rating system. The program allows several
functionalities such as: adding a new restaurant listing to the directory, deleting a listing if the restaurant
closed, displaying restaurants details, finding specific restaurant(s), and rating a restaurant. 
*/


//Header files
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<iomanip>
using namespace std;


//Restaurant struct
struct Restaurant {
  string name;//stores name
  string address;//stores address
  string city;//stores city
  string state;//stores state
  int zipcode;//stores zip
  string type;//stores the type of food
  string website;//stores the website
  float rating;//stores the rating
  int reviewers;//stores how many reviewers 
};
//Function protoytpes
void addRestaurant(vector<Restaurant> &restaurant,ifstream &in);
void displayAll(vector<Restaurant> &restaurant);
void changeRating(vector<Restaurant> &restaurant, ifstream &in);
void remove(vector<Restaurant> &restaurant, ifstream &in);
void findByName(vector<Restaurant> &restaurant, ifstream &in);
void findByCriteria(vector<Restaurant> &restaurant, ifstream &in);
void topRated(vector<Restaurant> &restaurant, ifstream &in);
int main()
{
  float num; 

  //Restaurants vector
  vector<Restaurant> restaurants;
  //File read object
  ifstream in;
  //File path
  in.open("RestaurantsTrans.txt");
  //file read string
  string line;
  //File open check
  if (!in)
    {
      cout << "File can't be open!!!" << endl;
    }
  else
    {
    //Read unti end
      while (!in.eof())
	{
	  in >> line;
	  //Check each commands
	  if (line == "AddListing")
	    {
	      addRestaurant(restaurants, in);
	    }
	  else if (line == "DisplayAll")
	    {
	      for(int i = 0; i < restaurants.size(); i++)
		{
		  if (restaurants[i].reviewers != 0)
		    {
		      restaurants[i].rating = (restaurants[i].rating / restaurants[i].reviewers);
		    }
		}

	      displayAll(restaurants);
	    }
	  else if (line == "Rate")
	    {
	      changeRating(restaurants, in);
	    }
	  else if (line == "RemoveListing")
	    {
	      remove(restaurants, in);
	    }
	  else if (line == "FindByName")
	    {
	      findByName(restaurants, in);
	    }
	  else if (line == "FindByCriteria")
	    {
	      findByCriteria(restaurants, in);
	    }
	  else if (line == "FindTopRated")
	    {
	      topRated(restaurants, in);
	    }
	}
    }
    //End 
      
  return 0;
}

//Method to store restaurant details
void addRestaurant(vector<Restaurant> &restaurant, ifstream &in)
{
  Restaurant r;
  in >> r.name >> r.address >> r.city >> r.state >> r.zipcode >> r.type >> r.website;
  r.rating = 0;
  r.reviewers = 0;
  restaurant.push_back(r);
}

//Display restaurant details
void displayAll(vector<Restaurant> &restaurant)
{
  cout << "    Restaurant          City           Type            Rating           Reviewers " << endl;
  cout << "---------------------------------------------------------------------------------- " << endl;
 
  for (int i = 0; i < restaurant.size(); i++)
    {
      cout << fixed;
      cout << setw(16) << restaurant[i].name << setw(15) << restaurant[i].city << setw(15) << restaurant[i].type << setw(15) << setprecision(2) << restaurant[i].rating << setw(18) << restaurant[i].reviewers << endl;
    }
  cout << endl;
}

//Method to create rating
void changeRating(vector<Restaurant> &restaurant, ifstream &in) 
{
  string name;
  int review;
  float rating;
 
  in >> name >> rating;
  for (int i = 0; i < restaurant.size(); i++)
    {
      if (restaurant[i].name == name)
	{
	  if (rating >= 1 && rating <=5)
	    {
	      restaurant[i].rating += rating;
	      restaurant[i].reviewers++; 	 
	      return;
	    }   
	    
	  else
	    {
	      cout << "Rate " << name << " " << 0 << endl;
	      cout << "Rating should be a number from 1 to 5" << endl;
	      return;
	    }
	}
      
    }

  cout << "Restaurant " << name << " not found in the file!!!" << endl;
}

//Method to remove from vector
void remove(vector<Restaurant> &restaurant, ifstream &in)
{
  string name;
  in >> name;
  for (int i = 0; i < restaurant.size(); i++)
    {
      if (restaurant[i].name == name) 
	{
	  restaurant.erase(restaurant.begin()+(i-1));
	  cout << "RemoveListing " << name << endl;
	  return;
	}
    }
  cout << "No such restaurant exists" << endl;
}

//Method to find a restaurant by name
void findByName(vector<Restaurant> &restaurant, ifstream &in) 
{
  string name;
  in >> name;
  for (int i = 0; i < restaurant.size(); i++)
    {
      if (restaurant[i].name == name)
	{
	  cout << "FindByName Ristorante"<< endl;
	  cout << restaurant[i].name << ", " << restaurant[i].type << endl;
	  cout << restaurant[i].address << ", " << restaurant[i].city << " " <<restaurant[i].state<<" "<<restaurant[i].zipcode << endl;
	  cout << restaurant[i].website << endl;
	  cout << "rating: " << restaurant[i].rating << " ( " << restaurant[i].reviewers << " reviews )" << endl;
	  cout << endl;
	  return;
	}
    }
  cout << "FindByName " <<name<< endl;
  cout << "No such restaurant exist" << endl;
  cout << endl;
}

//Method to find the details of restaurant by criteria
void findByCriteria(vector<Restaurant> &restaurant, ifstream &in) 
{
  string type,city;
  in >> type>>city;
  for (int i = 0; i < restaurant.size(); i++)
    {
      if (restaurant[i].type == type && restaurant[i].city==city )
	{
	  cout << "FindBycriteria " <<type<<" "<<city<< endl;
	  cout << restaurant[i].name << endl;
	  cout << restaurant[i].address << ", " << restaurant[i].city << " " << restaurant[i].state << " " << restaurant[i].zipcode << endl;
	  cout << restaurant[i].website << endl;
	  cout << "rating: " << restaurant[i].rating << " ( " << restaurant[i].reviewers << " reviews )" << endl;
	  cout << endl;
	  return;
	}
    }
  cout << "FindBycriteria " << type << " " << city << endl;
  cout << "No such restaurant exist" << endl;
  cout << endl;
}

//Method to display top rated restaurant in the city
void topRated(vector<Restaurant> &restaurant, ifstream &in)
{
  string city;
  in >> city;
  float rate = 0.0;
  for (int i = 0; i < restaurant.size(); i++) 
    {
      if (restaurant[i].city == city)
	{
	  if (rate < restaurant[i].rating) 
	    {
	      rate = restaurant[i].rating;
	    }
	}
    }
  for (int i = 0; i < restaurant.size(); i++)
    {
      if (rate == restaurant[i].rating && restaurant[i].city == city)
	{
	  cout << "FindTopRated " << city << endl;
	  cout << restaurant[i].name << ", " << restaurant[i].type << endl;
	  cout << restaurant[i].address << ", " << restaurant[i].city << " " << restaurant[i].state << " " << restaurant[i].zipcode << endl;
	  cout << restaurant[i].website << endl;
	  cout << "rating: " << restaurant[i].rating << " ( " << restaurant[i].reviewers << " reviews )" << endl;
	  cout << endl;
	  return;
	}
    }
  cout << "FindTopRated " << city << endl;
  cout << "No such restaurant exist" << endl;
}

