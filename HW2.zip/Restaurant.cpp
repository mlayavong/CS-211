#include "Restaurant.h" 
#include <iostream> 
#include <iomanip> 

//default constructor
Restaurant::Restaurant()
{
  restaurantName = ""; 
  restaurantAddress ="";
  restaurantCity=""; 
  restaurantType= ""; 

  for(int i = 0; i < 4; i++)
    availableSeats[i] = 0;

  Reservation res; 
  reservations.push_back(res);

}
//overloading the default constructo 
Restaurant::Restaurant(string rName, string rAddress, string rCity, string rType, int rCapacity)
{

  restaurantName = rName; 
  restaurantAddress = rAddress;
  restaurantCity = rCity ;  
  restaurantType = rType;
  for(int i = 0; i < 4; i++)
    availableSeats[i] = rCapacity;// =  rCapacity[4]; 
}

//prints the info of each restaurant 
void Restaurant::printInfo()
{
  cout << left << setw(20) << restaurantName;
  cout << left << setw(20) << restaurantAddress; 
  cout << left << setw(20) << restaurantCity;
  cout << left << setw(20) << restaurantType; 
  cout << left << setw(10) <<  getAvailableSeats();

  cout << endl; 


}

//getter funtions 
string Restaurant::  getRestName() const
{
  return restaurantName; 

}

string Restaurant:: getRestAddress() const
{
  return restaurantAddress; 
}

string Restaurant:: getRestCity() const
{ 
  return restaurantCity; 
}

string Restaurant:: getRestType() const
{ 
  return restaurantType; 
}

int Restaurant:: getAvailableSeats() const 
{ 
  return availableSeats[0]; 
}

//setters functions 
void Restaurant:: setRestName(string rName) 
{
  restaurantName = rName; 
}

void Restaurant:: setRestAddress(string rAddress)
{
  restaurantAddress = rAddress; 
} 

void Restaurant:: setRestCity(string rCity) 
{
  restaurantCity = rCity; 
}

void Restaurant:: setRestType(string rType) 
{
  restaurantType = rType; 
}

void Restaurant:: setAvailableSeats(int rCapacity)
{
  for(int i = 0; i < 4; i++) 
    availableSeats[i]; 
}

//uses the Reservation class to set reservations for each person
void Restaurant::MakeReservation(string cName, string cPhone, int gSize, int rTime) 
{
  availableSeats[0]= availableSeats[0] -gSize; 
  Reservation r(cName,cPhone, gSize, rTime);
  reservations.push_back(r);
}
//prints all reservations 
void Restaurant:: PrintReservation() const
{
  for(int i = 0; i <reservations.size(); i++)
    {
      reservations[i].printReservation();
      cout << endl;
    }

}
