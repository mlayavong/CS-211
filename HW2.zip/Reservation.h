#ifndef Reservation_h
#define Reservation_h

#include <string> 
using namespace std; 

class Reservation
{
 private: 
  string contactName;
  string contactPhone; 
  int groupSize; 
  int reservationTime;
  const long reservationNum; 
  static long nextReservationNum; 
 public: 
  //constructors 
  Reservation(); 
  Reservation(string cName, string cPhone, int gSize, int resTime);

  //accessors
  string getContactName() const; 
  string getContactPhone() const; 
  int getGroupSize() const; 
  int getReservationTime () const; 
  long getReservationNum() const; 
  //mutators
  void setContactName(string cName); 
  void setContactPhone(string cPhone); 
  void setGroupSize(int gSize); 
  void setReservationTime(int resTime); 

  void printReservation() const; 
  

};
#endif
