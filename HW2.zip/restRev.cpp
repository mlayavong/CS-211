#include "restRev.h" 
#include <fstream> 
#include <iomanip> 
#include <iostream> 

//default constructor 
RestaurantReservations::RestaurantReservations() 
{
  Restaurant r; 
  restaurants.push_back(r); 

}
//this reads data from the text file to output
void RestaurantReservations:: ProcessTransactionFile(string fileName) 
{ 
  ifstream fin;
  string rName, rAddress, rCity, rType, cName, cPhone;
  int rCapacity, rGroup, rTime, rNum; 

  string temp; 

  fin.open(fileName);

  if(!fin)
    cout << "File does not exisit"; 
  else 
    while(fin >> temp)
      { 
	if(temp == "CreateNewRestaurant") 
	  { 
	    fin >> rName >> rAddress >> rCity >> rType >> rCapacity; 
	    RestaurantReservations:: CreateNewRestaurant(rName, rAddress, rCity, rType, rCapacity); 
	  }
	else if(temp == "PrintAllRestaurants")
	  { 
	    RestaurantReservations:: printAllRestaurants();
	  }
	else if(temp == "FindTable") 
	  {
	    fin >> rCity >> rType >> rGroup >> rTime; 
	    RestaurantReservations:: findTable(rCity, rType, rGroup, rTime);
	  }
	else if(temp == "FindTableAtRestaurant") 
	  { 
	    fin >> rName >> rGroup; 
	    RestaurantReservations:: findTableAtRestaurant(rName, rGroup); 
	  } 
	else if(temp == "MakeReservation") 
	  {
	    fin >> rName >> cName >> cPhone >> rGroup >> rTime; 
	    RestaurantReservations:: makeReservation(rName, cName, cPhone, rGroup, rTime);
	  }
	else if(temp == "PrintRestaurantReservations") 
	  {
	    fin >> rName; 
	    RestaurantReservations:: printRestaurantReservations(rName); 
	  }

      }
  fin.close(); 
}
//creates a Restaurant object from the Restaurant class to read new restaurants 
void RestaurantReservations:: CreateNewRestaurant(string rName, string rAddress, string rCity, string rType, int rCapacity)
{
  Restaurant r(rName, rAddress, rCity, rType, rCapacity);
  restaurants.push_back(r);
}

//prints the restaurants information
void RestaurantReservations:: printAllRestaurants()
{
  cout <<  "Restaurant" << setw(20) << "Address" << setw(16) << "City" << setw(20) << "Type" << setw(20) << "Capacity" << endl;

  cout << "-----------------------------------------------------------------------------------------";

  for(int i = 0;i < restaurants.size(); i++) 
    restaurants[i].printInfo(); 

} 
//finds tables at the different restaurants and the times that are available
void RestaurantReservations:: findTable(string rCity, string rType, int rGroup, int rTime) 
{
  int count = 0; 
  for(int i = 0; i < restaurants.size(); i++) 
    { 
      if(restaurants[i].getRestCity() == rCity && restaurants[i].getRestType() == rType && restaurants[i].getAvailableSeats() >=  rGroup)
	{
	  cout << "You may reserve a table for " << rGroup << " at " << rTime << ":" << endl;
	  cout << restaurants[i].getRestName() << endl;
	  count += 1; 
	  
	}
      else;
    }
  if(count == 0)
    cout << "No restaurant can accommodate such a group at this time, check another time" << endl; 
}
//FInds times for different restaurants 
void RestaurantReservations::findTableAtRestaurant(string rName, int rGroup) 
{
  int count = 0; 
  for(int i= 0; i < restaurants.size(); i++)
    {
      if(restaurants[i].getRestName() == rName && restaurants[i].getAvailableSeats() <= rGroup)
	{
	  cout << "You can reserve a table for " << rGroup << " at " << rName << "." << endl; 	     
	  count += 1; 
	}
      else;
    }
  if(count == 0) 
    cout << rName << " does not have such availablity" << endl; 

}
//sets the reservations for each person 
void RestaurantReservations:: makeReservation(string rName, string cName, string cPhone, int rGroup, int rTime)
{
  int count = 0; 

  for(int i = 0; i < restaurants.size(); i++) 
    {
      if(restaurants[i].getRestName() == rName) 
	{
	  restaurants[i].MakeReservation(cName, cPhone, rGroup, rTime); 
	  count += 1; 
	}
      else;
    }
  if(count == 0) 
    cout << "The restaurant " << rName << " does not exist" << endl;

}
//prints all the reservations for each restaurant 
void RestaurantReservations:: printRestaurantReservations(string rName) 
{
  cout << rName << endl; 
  int count = 0 ; 

  
  for(int i = 0; i < restaurants.size(); i++) 
    { 
      if( restaurants[i].getRestName() == rName) 
	{
	  cout << left << setw(13) << "Reservation" << setw(14) << "Contact" << setw(17) << "Phone" << setw(13) << "Group" << setw(16) << "Time" << setw(10)  << endl;
	  cout << "------------------------------------------------------------------" << endl;	 
	  restaurants[i].PrintReservation(); 
	  count += 1; 
	}

    }
  if(count == 0) 
    cout << rName << " does not exist" << endl;

}

