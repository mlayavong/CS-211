#ifndef restRes_H
#define  restRes_H
#include "Reservation.h" 
#include "Restaurant.h" 
#include <vector> 
#include <string> 
using namespace std; 

//Restaurant Reservations class
class RestaurantReservations 
{ 
 private:
  vector<Restaurant> restaurants;//vector for restaurants  

 public: 
  //function prototypes
  RestaurantReservations(); 
  void ProcessTransactionFile(string fileName); 
  void CreateNewRestaurant(string rName, string rAddress, string rCity, string rType, int rCapacity); 
  void printAllRestaurants(); 
  void findTable(string rCity, string rType, int rGroup, int rTime);
  void findTableAtRestaurant(string rName, int rGroup);
  void makeReservation(string rName, string cName, string cPhone, int rGroup, int rTime); 
  void printRestaurantReservations(string rName); 


};
#endif
