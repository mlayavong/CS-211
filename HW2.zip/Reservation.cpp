#include "Reservation.h" 
#include <iostream> 
#include <iomanip> 

//constant 
long Reservation:: nextReservationNum = 100; 

//Default constructor
Reservation:: Reservation():reservationNum(nextReservationNum)   
{ 
  contactName = "";
  contactPhone =""; 
  groupSize = 0; 
  reservationTime = 0; 

}
//overloading the default constructor 
Reservation::Reservation(string cName, string cPhone, int gSize, int resTime):reservationNum(nextReservationNum)
{ 
  contactName = cName; 
  contactPhone = cPhone; 
  groupSize = gSize; 
  reservationTime = resTime; 
  nextReservationNum+=10; 

}
//getter functions 
string Reservation:: getContactName() const
{ 
  return contactName; 
}
string Reservation:: getContactPhone()const 
{ 
  return contactPhone; 
}
int Reservation:: getGroupSize()const
{ 
  return groupSize; 
}
int Reservation:: getReservationTime() const
{ 
  return reservationTime; 
}

long Reservation:: getReservationNum() const
{
  return nextReservationNum;
}

//setters
void Reservation:: setContactName(string cName)
{ 
  contactName = cName; 
} 
void Reservation:: setContactPhone(string cPhone) 
{ 
  contactPhone = cPhone; 
}
void Reservation:: setGroupSize(int gSize)
{ 
  groupSize = gSize; 
}
void Reservation:: setReservationTime(int resTime) 
{
  reservationTime = resTime; 
}
//prints the reservations
void Reservation:: printReservation() const
{
  cout << left << setw(13) << reservationNum << setw(14) << contactName << setw(18) << contactPhone << setw(12) << groupSize << reservationTime << ":00 PM";


}
