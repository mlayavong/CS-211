#ifndef Restaurant_h
#define Restaurant_h
#include "Reservation.h"
#include<vector> 
#include <string> 
using namespace std; 

class Restaurant 
{
 private:
  string restaurantName; 
  string restaurantAddress; 
  string restaurantCity; 
  string restaurantType; 
  int availableSeats[4];
  vector<Reservation> reservations; 

 public:
  //constructors 
  Restaurant(); 
  Restaurant(string rName, string rAddress, string rCity, string rType, int rCapacity);
  void  printInfo();
  //accessor 
  string getRestName() const; 
  string getRestAddress() const; 
  string getRestCity () const ; 
  string getRestType() const;  
  int getAvailableSeats() const;

  //mutators 
  void setRestName(string rName); 
  void setRestAddress(string rAddress); 
  void setRestCity(string rCity); 
  void setRestType(string rType);
  void setAvailableSeats(int rCapacity);
  void MakeReservation(string cName, string cPhone, int gSize, int resTime); 
  void PrintReservation() const;


};
#endif 
