#include"Reservation.h" 
#include "Restaurant.h" 
#include "restRev.h"
#include <iostream> 

int main() 
{ 
  RestaurantReservations openTable;

  //opens TransactionFile to read and output all information 
  openTable.ProcessTransactionFile("TransactionFile.txt"); 

  return 0; 
}
