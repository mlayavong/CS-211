#include"Queue.h" 
#include <iostream> 
using namespace std;


int main()
{
 
  Queue q;
  //pop the first element from the queue
  string s=q.dequeue();

  while(s.length() <3) //dequeue the elements till the length less than 3 , here we also enueue the strings
    {
      cout<<s<<endl;
      q.enqueue(s+'A');
      q.enqueue(s+'B');
      q.enqueue(s+'C');
      s=q.dequeue();
    }
  cout<<s<<endl;
  while(!q.isEmpty()) //now remove remaining elements from the queue
    {
      s=q.dequeue();
      cout<<s<<endl;
    }

return 0; 
 
}


