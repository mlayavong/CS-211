#include "Stack.h" 
#include <iostream>
/*
Stack:: Stack()
{ 
  top = nullptr; 
}
Stack:: ~Stack() 
{ 
  destroy(); 
}
void Stack:: destroy() 
{
  StackNode* nodePtr;
  StackNode* nextNode;

  nodePtr = top;

  while(nodePtr != nullptr) 
    { 

      nextNode = nodePtr -> next;

      delete nodePtr;

      nodePtr = nextNode;
    }

}
bool Stack:: isEmpty() const
{ 
  if(top == nullptr) 
    return true; 
  else 
    return false; 
}
void Stack:: push(el_t elem) 
{
  StackNode* newNode = new StackNode; 

  newNode -> element = elem; 
  newNode -> next = top; 
  top = newNode; 
}
void Stack:: pop(el_t& elem) 
{ 
  StackNode* nodePtr; 

  nodePtr = top; 

  if(!isEmpty()) 
    { 
      elem = nodePtr -> element;   
      top = nodePtr -> next; 
      delete nodePtr; 
      nodePtr= nullptr; 


    }
}

void Stack:: getTop(el_t& elem) const 
{ 
  if(!isEmpty()) 
    elem = top -> element; 

}
void Stack:: displayAll() const
{ 
  StackNode* nodePtr; 

  nodePtr = top; 
  while(nodePtr != nullptr)
    { 
      cout << nodePtr -> element << endl;
      nodePtr = nodePtr -> next; 
    } 
  cout << endl; 

}
*/

//constructor 
Stack::Stack()
{
  top = -1;
}

//pushes the character into the stack 
void Stack:: push(el_t elem)
{
  if(isFull())
    {
      cout << "Stack is full, please delete some" << endl;
    }
  else
    {
      top++;  //increments top
      el[top] = elem; //adds top element
    }
}
//clears everything in the stack for the new expression 
void Stack:: clear()
{ 
  top = -1; 
}

//takes out the last element that was pushed into the stack 
void Stack:: pop(el_t& elem)
{
  if(isEmpty())
    cout << "The stack is empty" << endl;
  else
    {
      elem = el[top]; //remove top element
      top--; // decrement top
    }

}
//checks the stack to see if it is full or not 
bool Stack:: isFull() const
{
  if(top == MAX - 1)
    return true;
  else
    return false;
}

//checks to the stack to see if is empty 
bool Stack:: isEmpty() const
{
  if(top == -1)
    return true;
  else
    return false;

}

//displays all contents in the stack
void Stack:: displayAll()const
{
  if(isEmpty())
    cout << "[ empty ]" << endl;
  else
    for(int i = top; i >= 0; i--)
      cout << el[i] << endl;
}

//gets the top of the stack 
int Stack:: getTop() 
{
  return top; 
}
