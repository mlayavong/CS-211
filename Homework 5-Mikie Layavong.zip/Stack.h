#ifndef STACK_h
#define STACK_h
#include<string> 
using namespace std; 

typedef char el_t; // creates an alias for char 
const int MAX = 20; 

class Stack
{ 
  //private functions 
 private: 
  el_t el[MAX]; //array
  int top; // holds top value 
  void destroy(); // destorys what is in the struct 
  /*
  struct StackNode
  { 
    el_t element; //letter in the node 
    StackNode* next; //pointer to the next node 
  };
  StackNode* top; 
  */
 public: 
  Stack(); //constructor 
  //  ~Stack();
  void push(el_t elem); //push function  
  void clear(); //clear function 
  void pop(el_t& elem); //pop function 
  bool isEmpty()const; //function to check if it is empty 
  bool isFull() const; //function to check if it is full 
  void displayAll() const; //displays all contents inside of funciton 
  int getTop(); //gets the top value 
 
 
};

#endif 
