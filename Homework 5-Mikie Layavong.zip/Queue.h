#ifndef QUEUE_h 
#define QUEUE_h 
#include <string> 
using namespace std; 

typedef char el_t;
const int MAX = 5; 

class Queue
{ 
 private: 
  el_t el[MAX]; 
  int front; //holds value for front 
  int rear; // holds value for rear
  int count; // counter 
  string queue[100]; //an array of strings 
 public: 
  //string queue[100]; 
  Queue(); 
  void enqueue(string s); 
  string dequeue();   
  // void enqueue(el_t let); 
  // void dequeue(el_t& let); 
  // bool isFull(); 
  bool isEmpty(); 
  // bool isEmpty() const; 
  void displayAll() const; 

};
#endif
