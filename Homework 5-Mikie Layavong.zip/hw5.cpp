#include "Stack.h" 
#include <iostream> 
using namespace std; 


//this function takes the users string input and checks whether the delimters are balanced or not
bool properlyBalanced(string input)
{
  Stack s;//to hold the stack 
  char x;// hold the chracters of the strings

  int i; // holds the index of each character 

  //loop to check the delimiters 
  for(int i = 0; i < input.length(); i++)
    {
      if(input[i] == '(' || input[i] == '[' || input[i] == '{')
        {
	  s.push(input[i]); //pushes the characters into the stack 
        }
      if(s.isEmpty() && ((input[i] == ')') || (input[i] == '}') || (input[i] == ']'))) // checks if there is an extra delimiter
        {
          cout << "Extra right delimiter" << endl;
          return false;
        }
      switch(input[i])
        {
        case ')':
          x = s.getTop();
          s.pop(x);//input[i]);
          if(x == '{' || x == '[')
            {
              cout << "deliminter mismatch" << endl;
              return false;
            }
	  break;

        case '}':
          x = s.getTop();
          s.pop(x);//input[i]);
          if(x == '(' || x == '[')
            {
              cout << "deliminted mismatch" << endl;
              return false;
            }
          break;

        case ']':
          x = s.getTop();
          s.pop(x);//input[i]);
          if(x == '(' || x == '{')
            {
              cout << "deliminted mismatch" << endl;
              return false;
            }
          break;

        }
    }
  if(s.isEmpty())
    return true;
  else
    {
      cout << "right delimiter missing: " << endl;
      return false;
    }

}


//main to execute a loop to check if each expression is properly balanced
int main() 
{ 
  Stack stack; 
  string expression; 
  int num; 

  while(true)
    {
      cout << "Enter 1 to exit or 0 to enter expression: "; 
      cin>> num; 

      if(num == 1) 
	break; 
      else
	{ 
      cout << "Enter expression: "; 
      cin>> expression; 
      cout << endl; 

  if(properlyBalanced(expression))
    cout << "Balanced: " << endl; 
  else
    cout << "not balanced" << endl; 
  stack.clear(); 
    	}
    }
  return 0; 
}
