#include "Queue.h"
#include <iostream>
using namespace std; 

//constructor 
Queue:: Queue()
{ 
  front = 0; 
  rear = 2; 
  queue[0] = "A"; 
  queue[1] = "B"; 
  queue[2] = "C"; 
}
//function to add the characters into the queue
void Queue:: enqueue(string s)
{ 
  queue[++rear] = s; 
}

//takes out characters in the queue 
string Queue:: dequeue() 
{ 
  return queue[front++] ; 

}
//checks the queue to see if it is empty 
bool Queue :: isEmpty() 
{ 
  return front > rear; 
}


/*
Queue:: Queue() 
{ 
  front = -1;
  rear = -1;
  count = 0; 

}

bool Queue::isFull() 
{ 
  if(count == MAX)
    return true; 
  else 
    return false; 
}

bool Queue::isEmpty() const
{ 
  if(count == 0) 
    return true; 
  else
    return false; 

}

void Queue:: enqueue(el_t let) 
{ 
  if(isFull()) 
    cout << "The Queue is full" << endl; 
  else 
    { 
      rear = (rear + 1) % MAX;
      el[rear] = let;
      count++; 
    }


}

void Queue:: dequeue(el_t& let)
{
  if(isEmpty()) 
    cout << "The queue is empty" << endl; 
  else 
    {
      front = (front + 1) % MAX; 
      let = el[front]; 
      count--; 

    }


}

void Queue:: displayAll() const 
{ 
  if(isEmpty()) 
    cout << "The queue is empty" << endl; 
  else 
    { 
      if(front < rear) 
	{ 
	  for(int a = front + 1; a <= rear; a++) 
	    cout << el[a] << endl; 
	}
      else if(rear <= front) 
	{ 
	  for(int i = front +1; i <= MAX -1; i++) 
	    cout << el[i] << endl; 
	  for(int j = 0; j <= rear; j++) 
	    cout << el[j] << endl; 

	}
    }

}

*/
