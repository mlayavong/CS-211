/* 
This program searches for a matching index in an array 

*/
#include <iostream>

using namespace std;

//prototypes for the functions 
void fillArray(int arr[], int n) ;
int matchIndex(int arr[], int l,int r) ;

int main()
{
  int num;// stores size entered by the user for the array 

  //gets user input 
  cout << "Enter number of inputs: ";
  cin >> num;
  int array[num];// array to store users input 
  cout << endl;

  fillArray(array, num);
  cout << endl;
  int n = matchIndex(array,0,num - 1);

  //returns output statement if theres a matching index or not 
  if(n == -1)
    cout<<" Matching index does not exist" << endl;
  else
    cout<<" Matching index found at " << n << endl;

  return 0;
}

//fills the array with the users numbers 
void fillArray(int arr[], int n)
{
  for(int i = 0; i < n; i++)
    {
      cout << "Enter number: ";
      cin >> arr[i] ;
    }
}

//searchs through the array to find the matching index
int matchIndex(int arr[], int l, int r)
{
  if(l > r)
    return -1; // returns -1 if the left side of the array is bigger than the right
  if(l == r && arr[l] == l)
    return l; //returns true if the left and right are equal to each other 
  int mid = (l + r)/2; //midpoint of the index
  if(arr[mid] == mid)
    return mid; //returns mid of the index and the array value are equal 
  if (arr[mid] > mid)
    return matchIndex(arr,l,mid - 1); // recursive portion to search the left side of the array 
  else
    return matchIndex(arr,mid + 1,r); // searches through the right side of the array and index 
}


