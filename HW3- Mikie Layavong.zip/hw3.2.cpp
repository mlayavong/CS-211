/* 
This program gets a word for the user to list all possible outcomes 
*/ 

#include <iostream>
#include <string>
#include <vector>
using namespace std;

//prototype of the function 
vector<string> permute(string str1); 

int main()
{
  vector<string> word; // vector to store string elements 
  string w; // to store the users word 

  cout << "Enter a word: ";
  cin >> w;

  word = permute(w);

  for(int i=0; i<word.size(); i++) // prints out every combination of the word
    {
      cout << word[i] << endl;
    }
  return 0;
}

// this function takes the users word and rearranges them n! times 
vector<string> permute(string str1)
{
  vector<string> result; //vector to hold the string values  
  if(str1.length() == 1) //gets the string length and if it equals 1 then pushback into the vecto 
 {
   result.push_back(str1);
 }
  else
    {
      char c = str1[0]; //initializing c to the first character of the word
      vector<string> tmpresult = permute(str1.substr(1)); // a temp vector to hold a copy of the users word 
      for(int i=0; i<tmpresult.size(); i++) 
	{
	  string r = tmpresult[i]; 

	  // we need to insert c at all possible locations in r.
	  for(int j=0; j<r.length(); j++)
	    {
	      result.push_back(r.substr(0, j) + c + r.substr(j));
	    }
	  result.push_back(r + c);
	}
    }
  return result;
}







